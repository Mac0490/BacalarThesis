package com.example.app;

public class Member {
    String image,url;

    public Member(){

    }

    public String getImage() {

        return image;
    }

    public String getUrl() {

        return url;
    }

    public void setImage(String image) {

        this.image = image;
    }

    public void setUrl(String url) {

        this.url = url;
    }
}
